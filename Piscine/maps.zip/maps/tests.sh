./map.pl -5 -5 -2 > map---
./map.pl 10 -5 -2 > map--
./map.pl 10 15 -2 > map-
./map.pl 20 15 2 > map_norm
./map.pl 0 15 2 > map_0
./map.pl 20 0 2 > map_02
./map.pl 20 15 0 > map_dens_0
./map.pl 1 15 2 > map_1col
./map.pl 20 1 1 > map_1line
echo "map---\n"
../bsq maps/map---
echo "map--\n"
../bsq maps/map--
echo "map-\n"
../bsq maps/map-
echo "map_norm\n"
../bsq map_norm
echo "map_0\n"
../bsq map_0
echo "map_02\n"
../bsq map_02
echo "map_dens_0\n"
../bsq map_dens_0
echo "map_1col\n"
../bsq map_1col
echo "map_1line\n"
../bsq map_1line
echo "map_invalid_line\n"
../bsq map_invalid_line
echo "map_invalid_line2\n"
../bsq map_invalid_line2
echo "map_invalid_col\n"
../bsq map_invalid_col
echo "map_invalid_deskriptor\n"
../bsq map_invalid_deskriptor
echo "map_invalid_deskriptor2\n"
../bsq map_invalid_deskriptor2
echo "map_invalid_deskriptor3\n"
../bsq map_invalid_deskriptor3
echo "map_invalid_deskriptor4\n"
../bsq map_invalid_deskriptor4
echo "map_no_clean\n"
../bsq map_no_clean
echo "map_1_empty\n"
../bsq map_1_empty
echo "map_1_full\n"
../bsq map_1_full
echo "map_empty\n"
../bsq map_empty
echo "map_trash\n"
../bsq map_trash
echo "map_only_n\n"
../bsq map_only_n
